import React from "react";

function Note() {
  return (
   <div className="note">
     <h1>Javascript and React,js</h1>
     <p> Plain JS apps usually start with the initial UI created on the server (as HTML), whereas React apps start with a blank HTML page, and dynamically create the initial state in JavaScript.
React requires you to break your UI into components, but plain JS apps can be structured in any way you see it. </p>
   </div>
    );
}

export default Note;